respawn = "BASE";
respawnDelay = 15;

aiKills = 0;
disabledAI = 1;
Saving = 0;

class Header
{
	gameType = CTI;
	minplayers = 1;
	maxplayers = 53;
};

class CfgTaskEnhancements
{
  enable       = 1;
  3d           = 1;
  3dDrawDist   = 3500;
  share        = 1;
  propagate    = 1;
};

//If we have CBA for TFAR, then load the mission's settings.
cba_settings_hasSettingsFile = 1;
